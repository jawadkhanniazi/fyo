The QURAN database


First Time only:
===========
1. This program (proQuran.exe) uses the .NET Framework 4.0 (or above).
If not already installed, download and install the framework.

2. If you get an "OLEDB provider not installed" message,
download and install the AccessDatabaseEngine (2007).

3. Press <more info> RUN anyway,
if you get an Unknown Publisher or unrecognized app message.

4. Put downloaded recitation (and translation voice) files also in the same local folder.

5. For best results download and copy the language fonts to your Windows Fonts directory. 


Shortcut Keys:
===========
<F1> Help
<F4> Exit
<F5> Start / Stop Recitation
<F8> (toggle) Expanded view
<PageUp> Previous Ayat
<PageDown> Next Ayat
<Alt><C> Auto-adjust Colour


For the latest updates pl. visit:
=====================
https://qurandb.com
https://qurandb.wordpress.com
https://bik6236.wixsite.com/qurandb


Facebook:
=======
https://www.facebook.com/qurandb/




bik6236@gmail.com
